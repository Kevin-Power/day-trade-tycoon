# Classroom static server — localhost only, no install.
$ErrorActionPreference = "Stop"
$root = Join-Path $PSScriptRoot "app"
$port = 18765
$prefix = "http://127.0.0.1:$port/"
$mime = @{
  ".html"  = "text/html; charset=utf-8"
  ".js"    = "text/javascript; charset=utf-8"
  ".css"   = "text/css; charset=utf-8"
  ".svg"   = "image/svg+xml"
  ".json"  = "application/json"
  ".png"   = "image/png"
  ".jpg"   = "image/jpeg"
  ".jpeg"  = "image/jpeg"
  ".ico"   = "image/x-icon"
  ".woff2" = "font/woff2"
  ".map"   = "application/json"
  ".txt"   = "text/plain; charset=utf-8"
}
if (-not (Test-Path (Join-Path $root "index.html"))) {
  Write-Host "找不到 app\index.html，請勿只解壓部分檔案。"
  pause
  exit 1
}
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)
try {
  $listener.Start()
} catch {
  Write-Host $_.Exception.Message
  exit 1
}
Start-Process $prefix
Write-Host "當沖大富翁教室已啟動。關閉本視窗即停止。"
while ($listener.IsListening) {
  try { $ctx = $listener.GetContext() } catch { break }
  $reqPath = [Uri]::UnescapeDataString($ctx.Request.Url.LocalPath)
  if ($reqPath -eq "/") { $reqPath = "/index.html" }
  $rel = $reqPath.Replace("/", [IO.Path]::DirectorySeparatorChar).TrimStart("\")
  $full = [IO.Path]::GetFullPath((Join-Path $root $rel))
  $rootFull = [IO.Path]::GetFullPath($root)
  $res = $ctx.Response
  if (-not $full.StartsWith($rootFull)) {
    $res.StatusCode = 403
    $res.Close()
    continue
  }
  if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
    $res.StatusCode = 404
    $bytes = [Text.Encoding]::UTF8.GetBytes("Not found")
    $res.OutputStream.Write($bytes, 0, $bytes.Length)
    $res.Close()
    continue
  }
  $ext = [IO.Path]::GetExtension($full).ToLowerInvariant()
  if ($mime.ContainsKey($ext)) { $res.ContentType = $mime[$ext] }
  else { $res.ContentType = "application/octet-stream" }
  $bytes = [IO.File]::ReadAllBytes($full)
  $res.ContentLength64 = $bytes.Length
  $res.Headers.Add("Cache-Control", "no-cache")
  $res.OutputStream.Write($bytes, 0, $bytes.Length)
  $res.Close()
}
