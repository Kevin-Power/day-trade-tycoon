@echo off
cd /d "%~dp0"
title 當沖大富翁 地端教室
echo.
echo  當沖大富翁  地端教室
echo  關閉本視窗即停止。
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0serve.ps1"
if errorlevel 1 (
  echo PowerShell 無法啟動，改試 Python...
  cd app
  start "" http://127.0.0.1:18765/
  py -3 -m http.server 18765 2>nul
  if errorlevel 1 python -m http.server 18765
)
