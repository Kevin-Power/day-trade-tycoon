#!/bin/bash
cd "$(dirname "$0")/app"
PORT=18765
echo "當沖大富翁 地端教室"
echo "關閉本視窗即停止。"
(sleep 1; xdg-open "http://127.0.0.1:$PORT/" 2>/dev/null || open "http://127.0.0.1:$PORT/" 2>/dev/null) &
if command -v python3 >/dev/null 2>&1; then
  python3 -m http.server "$PORT" --bind 127.0.0.1
elif command -v python >/dev/null 2>&1; then
  python -m http.server "$PORT"
else
  echo "需要 Python 3 才能啟動。"
  read -r _
fi
